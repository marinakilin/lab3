package com.example.thirdlab;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;

public class MainAdapter extends ArrayAdapter<Worker> {

    public MainAdapter(Context context) {
        super(context, R.layout.item_list);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            convertView = inflater.inflate(R.layout.item_list, parent, false);
            holder = new ViewHolder(convertView);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final Worker worker = getItem(position);

        assert worker != null;
        holder.avatar.setImageResource(worker.getAvatarId());
        holder.name.setText(worker.getName());
        holder.age.setText(worker.getAge());
        holder.position.setText(worker.getPosition());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra("name",worker.getName());
                intent.putExtra("age", worker.getAge());
                intent.putExtra("position", worker.getPosition());
                intent.putExtra("avatar", worker.getAvatarId());
                intent.putExtra("des", worker.getDescription());
                context.startActivity(intent);
            }
        });
        return convertView;
    }

    static class ViewHolder {
        ImageView avatar;
        TextView name;
        TextView age;
        TextView position;
        TextView description;
        CardView cardView;

        ViewHolder(View view) {
            avatar = view.findViewById(R.id.avatarImageView);
            name = view.findViewById(R.id.nameText);
            age = view.findViewById(R.id.ageText);
            position = view.findViewById(R.id.positionText);
            description = view.findViewById(R.id.descriptionText);
            cardView = view.findViewById(R.id.card);
        }
    }
}
//}
//    @Override
//    public void onBindViewHolder(@NonNull final MainViewHolder holder, final int i) {
//        holder.avatar.setImageResource(list.get(i).getAvatarId());
//        holder.name.setText(list.get(i).getName());
//        holder.age.setText(list.get(i).getAge());
//        holder.position.setText(list.get(i).getPosition());
//
//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Context context = v.getContext();
//                Intent intent = new Intent(context, DetailsActivity.class);
//                intent.putExtra("name", list.get(i).getName());
//                intent.putExtra("age", list.get(i).getAge());
//                intent.putExtra("position", list.get(i).getPosition());
//                intent.putExtra("avatar", list.get(i).getAvatarId());
//                intent.putExtra("des", list.get(i).getDescription());
//                context.startActivity(intent);
//            }
//        });
//    }
//
//}
