package com.example.thirdlab;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

import static com.example.thirdlab.R.drawable.face1;
import static com.example.thirdlab.R.drawable.face2;
import static com.example.thirdlab.R.drawable.face3;
import static com.example.thirdlab.R.drawable.face4;
import static com.example.thirdlab.R.drawable.face5;
import static com.example.thirdlab.R.drawable.face6;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actirvity_details);

        TextView name = findViewById(R.id.nameText);
        TextView age = findViewById(R.id.ageText);
        TextView position = findViewById(R.id.positionText);
        ImageView avatar = findViewById(R.id.avatarImageView);
        TextView description = findViewById(R.id.descriptionText);

        name.setText(getIntent().getStringExtra("name"));
        age.setText(getIntent().getStringExtra("age"));
        position.setText(getIntent().getStringExtra("position"));
        description.setText(getIntent().getStringExtra("des"));

        switch (Objects.requireNonNull(getIntent().getStringExtra("name"))) {
            case "Вася":
                avatar.setImageResource(face1);
                break;
            case "Петя":
                avatar.setImageResource(face2);
                break;
            case "Сережа":
                avatar.setImageResource(face3);
                break;
            case "Татьяна":
                avatar.setImageResource(face4);
                break;
            case "Коля":
                avatar.setImageResource(face5);
                break;
            case "Иннокентий":
                avatar.setImageResource(face6);
                break;
        }
    }

}