package com.example.thirdlab;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView lv = findViewById(R.id.listCards);

        MainAdapter adapter = new MainAdapter(this);
        lv.setAdapter(adapter);
        adapter.addAll(new Worker("Вася", R.drawable.face1, "23", "Начальник отдела", "С коллегами находится в дружеских отношениях. Доброжелателен и сдержан, в любой ситуации готов к мирному решению конфликта. Вредные привычки отсутствуют. Имеет правильные жизненные приоритеты и ориентиры. С удовольствием участвует в общественной жизни коллектива.обладает обширным объемом знаний по имеющейся специальности и всегда находится в курсе последних событий в своей области. Обладает отличными навыками деловых переговоров. зарекомендовал себя как ответственный сотрудник, нацеленный на отличный результат, всегда готов к быстрому принятию инновационных решений и несению ответственности за их принятие и за действия подчиненных. Готов к работе в любых условиях, в т. ч. в нерабочее время. Отличается пунктуальностью, деликатностью в общении с подчиненными и коллегами, за что имеет уважение в коллективе. Требователен к самому себе."),
                new Worker("Петя", R.drawable.face2, "44", "Охранник", "Пьет на работе"),
                new Worker("Сережа", R.drawable.face3, "32", "Бухгалтер", "Высококвалифицированный специалист и порядочный человек. Всего достигает своим трудом и знаниями. Человек на которого можно положиться."),
                new Worker("Татьяна", R.drawable.face4, "19", "Стажер", "Вся работа выполнена качественно, но не совсем в срок."),
                new Worker("Коля", R.drawable.face5, "49", "Бухгалтер", "Слабый специалист. \"Дружит\" только с нужными людьми, ради роста по карьерной лестнице - пойдет на многое, даже \"стучать\" начальству, подхалим."),
                new Worker("Иннокентий", R.drawable.face6, "22", "Администратор", "Старательный работник, всегда на рабочем месте, стремится выполнить работу быстро"));


    }
}
