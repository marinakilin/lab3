package com.example.thirdlab;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainViewHolder>{

    private List<Worker> list;

    public MainAdapter(List<Worker> list, Context context) {
        this.list = list;
    }

    @NonNull
    @Override
    public MainViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_list, parent, false);
        v.getBackground().setAlpha(0);

        return new MainViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MainViewHolder holder, final int i) {
        holder.avatar.setImageResource(list.get(i).getAvatarId());
        holder.name.setText(list.get(i).getName());
        holder.age.setText(list.get(i).getAge());
        holder.position.setText(list.get(i).getPosition());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context , DetailsActivity.class);
                intent.putExtra("name", list.get(i).getName());
                intent.putExtra("age", list.get(i).getAge());
                intent.putExtra("position", list.get(i).getPosition());
                intent.putExtra("avatar", list.get(i).getAvatarId());
                intent.putExtra("des", list.get(i).getDescription());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
