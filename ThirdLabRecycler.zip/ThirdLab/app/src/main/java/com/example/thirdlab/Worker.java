package com.example.thirdlab;

class Worker {


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getAvatarId() {
        return avatarId;
    }

    public void setAvatarId(int avatarId) {
        this.avatarId = avatarId;
    }

    String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    private String name;
    private int avatarId;
    private String age;
    private String position;
    private String description;


    Worker(String name, int avatarId, String age, String position, String description) {
        this.name = name;
        this.avatarId = avatarId;
        this.age = age;
        this.position = position;
        this.description = description;
    }
}
