package com.example.thirdlab;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class MainViewHolder extends RecyclerView.ViewHolder {

    ImageView avatar;
    TextView name;
    TextView age;
    TextView position;

    MainViewHolder(@NonNull View itemView) {
        super(itemView);

        avatar = itemView.findViewById(R.id.avatarImageView);
        name = itemView.findViewById(R.id.nameText);
        age = itemView.findViewById(R.id.ageText);
        position = itemView.findViewById(R.id.positionText);
    }
}

